// Theme.h - UI Theme Setup
#ifndef THEME_H
#define THEME_H

#include "imgui.h"

// Setup the purple glassmorphism dark theme
void SetupTheme();

#endif
