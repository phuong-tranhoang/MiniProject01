# PhuongTH33 Music Player - UML Class Diagram

```mermaid
classDiagram
    direction TB
    
    class Song {
        +int id
        +string title
        +string artist
        +string album
        +string filePath
        -static atomic~int~ nextId
        +Song()
        +Song(title, artist, album)
    }
    
    class MusicLibrary {
        -vector~Song~ songs
        -unordered_map~int, Song*~ songIndexByID
        -unordered_map~string, Song*~ songIndexByTitle
        -unordered_map~string, vector~Song*~~ artistIndex
        +getAllSongs() vector~Song~
        +addSong(song) bool
        +getSize() size_t
        +findSongByID(id) Song*
        +findSongByTitle(title) Song*
        +findSongByArtist(artist) vector~Song*~
        +clear()
    }
    
    class PlaybackQueue {
        -list~Song*~ queue
        +addSong(song)
        +removeSong(songID)
        +clearQueue()
        +getQueueSize() size_t
        +getNextSong() Song*
        +getQueueList() list~Song*~
        +addAlbumToQueue(album, library) size_t
    }
    
    class PlaybackHistory {
        -stack~Song*~ history
        -vector~Song*~ forward
        +getPreviousSong() Song*
        +getForwardSong() Song*
        +getHistoryList() vector~Song*~
        +getForwardList() vector~Song*~
        +addSongToHistory(song)
        +addSongToForward(song)
        +clearHistory()
        +clearForward()
        +getHistorySize() size_t
        +getForwardSize() size_t
    }
    
    class ShuffleManager {
        -vector~Song*~ shuffleQueue
        -unordered_set~Song*~ shuffleHistory
        -size_t index
        +shuffleAll()
        +enableShuffle(queue)
        +getNextSong() Song*
        +checkAutoLoop()
        +addSong(song)
        +getShuffleList() vector~Song*~
        +getCurrentIndex() size_t
        +clear()
    }
    
    class AudioEngine {
        -ma_engine engine
        -ma_sound sound
        -bool initialized
        +init()
        +playFile(filepath)
        +isPlaying() bool
        +togglePause()
        +seekTo(seconds)
        +getCurrentTime() float
        +getTotalDuration() float
        +isFinished() bool
        +stop()
    }
    
    class MusicPlayer {
        -MusicLibrary library
        -PlaybackQueue queue
        -ShuffleManager shuffleMgr
        -PlaybackHistory stack
        -unordered_set~string~ loadedFolders
        -bool isShuffleEn
        -Song* current
        -PlaybackQueue smartPlaylist
        +AudioEngine engine
        +loadLibrary(path)
        +getLibrary() MusicLibrary
        +playSong()
        +playNext()
        +playPrevious()
        +addSongToQueue(song)
        +removeSongFromQueue(song)
        +addAlbumToQueue(album)
        +enableShuffle()
        +disableShuffle()
        +isShuffleEnabled() bool
        +chooseAndPlaySong(song)
        +clearQueue()
        +getCurrentSong() Song*
        +generateSmartPlaylist(song, size)
        +applySmartPlaylist()
        +getQueueManager() PlaybackQueue
        +getHistoryManager() PlaybackHistory
        +getShuffleManager() ShuffleManager
        +clearHistory()
        +clearLibrary()
        +addArtistToQueue(artist) size_t
    }
    
    class UIComponents {
        <<module>>
        +Tab currentTab
        +MusicPlayer player
        +char[] searchBuf
        +string toastMessage
        +showToast(message)
        +formatTime(seconds) string
        +containsString(haystack, needle) bool
        +RenderSongItem(song, spacious, inQueue)
        +RenderAlbumsTab()
        +RenderSmartPlaylistButton(song)
        +RenderToast()
        +RenderMainUI(pathBuffer)
    }
    
    class Theme {
        <<module>>
        +SetupTheme()
    }

    MusicPlayer *-- MusicLibrary
    MusicPlayer *-- PlaybackQueue
    MusicPlayer *-- ShuffleManager
    MusicPlayer *-- PlaybackHistory
    MusicPlayer *-- AudioEngine
    
    MusicLibrary o-- Song
    PlaybackQueue o-- Song
    PlaybackHistory o-- Song
    ShuffleManager o-- Song
    
    UIComponents ..> MusicPlayer
    UIComponents ..> Theme
```

## Sequence: Enable Shuffle

```mermaid
sequenceDiagram
    User->>UI: Click Shuffle
    UI->>MP: enableShuffle()
    MP->>PQ: getQueueList()
    MP->>SM: enableShuffle(queue)
    SM->>SM: shuffleAll()
    MP-->>UI: Update button
```

## Sequence: Play Previous

```mermaid
sequenceDiagram
    User->>UI: Click Previous
    UI->>MP: playPrevious()
    MP->>PH: getPreviousSong()
    alt current != null
        MP->>PH: addSongToForward(current)
    end
    MP->>MP: current = prev
    MP->>AE: playFile()
```

## Components

| Component | Role |
|-----------|------|
| Song | Song metadata |
| MusicLibrary | Song storage & indexing |
| PlaybackQueue | Upcoming songs |
| PlaybackHistory | Back/forward navigation |
| ShuffleManager | Random playback |
| AudioEngine | Audio via miniaudio |
| MusicPlayer | Main orchestrator |
| UIComponents | ImGui UI rendering |
| Theme | Purple glassmorphism styling |
